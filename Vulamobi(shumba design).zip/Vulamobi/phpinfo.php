<?php

echo phpinfo();

?>
