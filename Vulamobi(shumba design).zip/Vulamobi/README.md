Vulamobi
--------
The backend of the mobile interface for Vulamobi, a CS Honours 2012 project.