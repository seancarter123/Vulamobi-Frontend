<?php
	session_destroy();
	header( 'Location: index.php' ) ;
	echo "redirecting to login ...";
?>
